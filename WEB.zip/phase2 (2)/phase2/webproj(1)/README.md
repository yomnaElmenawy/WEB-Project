# AIU Global Hub Backend

This project now has a simple Node.js, Express.js, and SQLite backend in the `backend` folder. The frontend uses `fetch()` to call the API at `http://localhost:3000`.

## Install Dependencies

```bash
cd backend
npm install
```

## Run The Server

```bash
npm start
```

Open the frontend through the server:

```text
http://localhost:3000/index.html
```

The SQLite database file is created automatically at:

```text
backend/database.sqlite
```

## Default Login Accounts

Admin:

```text
admin@aiu.edu.eg / 123456
```

Student:

```text
student@aiu.edu.eg / 123456
```

## API Routes

Authentication:

```text
POST /api/auth/login
POST /api/auth/register
```

Opportunities:

```text
GET    /api/opportunities
GET    /api/opportunities/:id
POST   /api/opportunities
PUT    /api/opportunities/:id
DELETE /api/opportunities/:id
```

Applications:

```text
POST /api/applications
GET  /api/applications/student/:userId
GET  /api/applications
```

Manager/admin-only routes require this request header from the frontend:

```text
x-user-role: admin
```

## How To Test

1. Run `cd backend`.
2. Run `npm install`.
3. Run `npm start`.
4. Open `http://localhost:3000/login.html`.
5. Login as `student@aiu.edu.eg` with password `123456`.
6. Open `http://localhost:3000/index.html` or `http://localhost:3000/opportunities.html` to see dynamic opportunity data.
7. Open an opportunity detail page and apply as a student.
8. Logout, then login as `admin@aiu.edu.eg` with password `123456`.
9. Open `http://localhost:3000/opportunity-manager.html` to add, edit, and delete opportunities.
