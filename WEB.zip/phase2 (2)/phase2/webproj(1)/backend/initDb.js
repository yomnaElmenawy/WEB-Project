const bcrypt = require('bcrypt');
const { run, get } = require('./db');

async function createTables() {
  await run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('student', 'admin', 'manager')),
      university_id TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS opportunities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      field TEXT NOT NULL,
      location TEXT NOT NULL,
      provider TEXT NOT NULL,
      term TEXT NOT NULL,
      description TEXT NOT NULL,
      requirements TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS applications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      opportunity_id INTEGER NOT NULL,
      statement TEXT,
      recommendation_professor TEXT,
      graduation_year TEXT,
      status TEXT NOT NULL DEFAULT 'submitted',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (opportunity_id) REFERENCES opportunities(id) ON DELETE CASCADE,
      UNIQUE(user_id, opportunity_id)
    )
  `);
}

async function seedUsers() {
  const users = [
    {
      name: 'AIU Admin',
      email: 'admin@aiu.edu.eg',
      password: '123456',
      role: 'admin',
      universityId: 'ADMIN001'
    },
    {
      name: 'AIU Student',
      email: 'student@aiu.edu.eg',
      password: '123456',
      role: 'student',
      universityId: 'STU001'
    }
  ];

  for (const user of users) {
    const existing = await get('SELECT id FROM users WHERE email = ?', [user.email]);
    if (!existing) {
      const hash = await bcrypt.hash(user.password, 10);
      await run(
        'INSERT INTO users (name, email, password_hash, role, university_id) VALUES (?, ?, ?, ?, ?)',
        [user.name, user.email, hash, user.role, user.universityId]
      );
    }
  }
}

async function seedOpportunities() {
  const countRow = await get('SELECT COUNT(*) AS count FROM opportunities');
  if (countRow.count > 0) return;

  const opportunities = [
    {
      title: 'Ontario Tech Research Internship',
      category: 'Internship',
      field: 'Computer Science',
      location: 'Oshawa, Ontario, Canada',
      provider: 'Ontario Tech University',
      term: 'Summer 2026',
      description: 'Work with an international research team on applied AI, data analysis, and software prototypes.',
      requirements: 'AIU Computer Science or Engineering student; GPA 3.0+; Python or JavaScript experience.'
    },
    {
      title: 'UofL 2+2 Undergraduate Program',
      category: 'Dual Degree',
      field: 'Bioengineering',
      location: 'Louisville, Kentucky, USA',
      provider: 'University of Louisville',
      term: 'Two Years',
      description: 'Complete part of your undergraduate studies abroad through a structured dual-degree pathway.',
      requirements: 'Strong academic standing; department approval; English language readiness.'
    },
    {
      title: 'WVU 3+1 Cyber Security',
      category: 'Dual Degree',
      field: 'Cyber Security',
      location: 'Morgantown, West Virginia, USA',
      provider: 'West Virginia University',
      term: 'One Year',
      description: 'Study cyber security topics including secure systems, networking, and incident response.',
      requirements: 'Computer Science student; networking basics; GPA 3.0+.'
    },
    {
      title: 'Jean Moulin Lyon 3 Exchange',
      category: 'Exchange Semester',
      field: 'Business',
      location: 'Lyon, France',
      provider: 'Jean Moulin Lyon 3 University',
      term: 'One Semester',
      description: 'Join a semester exchange focused on business, communication, and international management.',
      requirements: 'Business student; good academic standing; international office approval.'
    },
    {
      title: 'Hive AI Innovation Studio Internship',
      category: 'Internship',
      field: 'Artificial Intelligence',
      location: 'Louisville, Kentucky, USA',
      provider: 'University of Louisville',
      term: 'Summer 2025',
      description: 'Join a research studio focused on malware detection, cybersecurity datasets, and AI pipelines.',
      requirements: 'Python knowledge; machine learning basics; strong academic standing.'
    }
  ];

  for (const item of opportunities) {
    await run(
      `INSERT INTO opportunities
       (title, category, field, location, provider, term, description, requirements)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        item.title,
        item.category,
        item.field,
        item.location,
        item.provider,
        item.term,
        item.description,
        item.requirements
      ]
    );
  }
}

async function initDb() {
  await createTables();
  await seedUsers();
  await seedOpportunities();
}

module.exports = initDb;
