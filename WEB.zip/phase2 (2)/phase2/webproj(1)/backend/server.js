const path = require('path');
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const initDb = require('./initDb');
const { run, get, all } = require('./db');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'webproj')));

function publicUser(user) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    universityId: user.university_id
  };
}

function requireManager(req, res, next) {
  const role = req.headers['x-user-role'];
  if (role === 'admin' || role === 'manager') {
    next();
    return;
  }
  res.status(403).json({ message: 'Only admin or manager users can do this action.' });
}

app.get('/api/health', (req, res) => {
  res.json({ message: 'AIU Global Hub API is running.' });
});

app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password, universityId } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ message: 'Name, email, and password are required.' });
    }
    if (!email.endsWith('@aiu.edu.eg')) {
      return res.status(400).json({ message: 'Please register with your AIU email address.' });
    }

    const existing = await get('SELECT id FROM users WHERE email = ?', [email]);
    if (existing) {
      return res.status(409).json({ message: 'An account with this email already exists.' });
    }

    const hash = await bcrypt.hash(password, 10);
    const result = await run(
      'INSERT INTO users (name, email, password_hash, role, university_id) VALUES (?, ?, ?, ?, ?)',
      [name, email, hash, 'student', universityId || null]
    );

    const user = await get('SELECT * FROM users WHERE id = ?', [result.id]);
    res.status(201).json({ message: 'Registration successful.', user: publicUser(user) });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Could not register right now. Please try again.' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required.' });
    }

    const user = await get('SELECT * FROM users WHERE email = ?', [email]);
    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password.' });
    }

    const passwordMatches = await bcrypt.compare(password, user.password_hash);
    if (!passwordMatches) {
      return res.status(401).json({ message: 'Invalid email or password.' });
    }

    res.json({ message: 'Login successful.', user: publicUser(user) });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Could not login right now. Please try again.' });
  }
});

app.get('/api/opportunities', async (req, res) => {
  try {
    const opportunities = await all('SELECT * FROM opportunities ORDER BY id DESC');
    res.json(opportunities);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Could not load opportunities.' });
  }
});

app.get('/api/opportunities/:id', async (req, res) => {
  try {
    const opportunity = await get('SELECT * FROM opportunities WHERE id = ?', [req.params.id]);
    if (!opportunity) {
      return res.status(404).json({ message: 'Opportunity not found.' });
    }
    res.json(opportunity);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Could not load this opportunity.' });
  }
});

app.post('/api/opportunities', requireManager, async (req, res) => {
  try {
    const { title, category, field, location, provider, term, description, requirements, status } = req.body;
    if (!title || !category || !field || !location || !provider || !term) {
      return res.status(400).json({ message: 'Please fill all required opportunity fields.' });
    }

    const result = await run(
      `INSERT INTO opportunities
       (title, category, field, location, provider, term, description, requirements, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        title,
        category,
        field,
        location,
        provider,
        term,
        description || '',
        requirements || '',
        status || 'active'
      ]
    );

    const created = await get('SELECT * FROM opportunities WHERE id = ?', [result.id]);
    res.status(201).json({ message: 'Opportunity created.', opportunity: created });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Could not create opportunity.' });
  }
});

app.put('/api/opportunities/:id', requireManager, async (req, res) => {
  try {
    const { title, category, field, location, provider, term, description, requirements, status } = req.body;
    const result = await run(
      `UPDATE opportunities
       SET title = ?, category = ?, field = ?, location = ?, provider = ?,
           term = ?, description = ?, requirements = ?, status = ?
       WHERE id = ?`,
      [title, category, field, location, provider, term, description || '', requirements || '', status || 'active', req.params.id]
    );

    if (result.changes === 0) {
      return res.status(404).json({ message: 'Opportunity not found.' });
    }

    const updated = await get('SELECT * FROM opportunities WHERE id = ?', [req.params.id]);
    res.json({ message: 'Opportunity updated.', opportunity: updated });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Could not update opportunity.' });
  }
});

app.delete('/api/opportunities/:id', requireManager, async (req, res) => {
  try {
    const result = await run('DELETE FROM opportunities WHERE id = ?', [req.params.id]);
    if (result.changes === 0) {
      return res.status(404).json({ message: 'Opportunity not found.' });
    }
    res.json({ message: 'Opportunity deleted.' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Could not delete opportunity. It may already have applications.' });
  }
});

app.post('/api/applications', async (req, res) => {
  try {
    const { userId, opportunityId, statement, recommendationProfessor, graduationYear } = req.body;
    if (!userId || !opportunityId) {
      return res.status(400).json({ message: 'User and opportunity are required.' });
    }

    const user = await get('SELECT * FROM users WHERE id = ?', [userId]);
    if (!user || user.role !== 'student') {
      return res.status(403).json({ message: 'Only student users can apply for opportunities.' });
    }

    const result = await run(
      `INSERT INTO applications
       (user_id, opportunity_id, statement, recommendation_professor, graduation_year)
       VALUES (?, ?, ?, ?, ?)`,
      [userId, opportunityId, statement || '', recommendationProfessor || '', graduationYear || '']
    );

    res.status(201).json({ message: 'Application submitted successfully.', applicationId: result.id });
  } catch (error) {
    if (error.message && error.message.includes('UNIQUE')) {
      return res.status(409).json({ message: 'You already applied for this opportunity.' });
    }
    console.error(error);
    res.status(500).json({ message: 'Could not submit application.' });
  }
});

app.get('/api/applications/student/:userId', async (req, res) => {
  try {
    const applications = await all(
      `SELECT applications.*, opportunities.title AS opportunity_title
       FROM applications
       JOIN opportunities ON applications.opportunity_id = opportunities.id
       WHERE applications.user_id = ?
       ORDER BY applications.created_at DESC`,
      [req.params.userId]
    );
    res.json(applications);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Could not load student applications.' });
  }
});

app.get('/api/applications', requireManager, async (req, res) => {
  try {
    const applications = await all(
      `SELECT applications.*, users.name AS student_name, users.email AS student_email,
              opportunities.title AS opportunity_title
       FROM applications
       JOIN users ON applications.user_id = users.id
       JOIN opportunities ON applications.opportunity_id = opportunities.id
       ORDER BY applications.created_at DESC`
    );
    res.json(applications);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Could not load applications.' });
  }
});

initDb()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  })
  .catch((error) => {
    console.error('Database initialization failed:', error);
  });
