const API_BASE_URL = 'http://localhost:3000/api';

function getCurrentUser() {
  const userJson = sessionStorage.getItem('user');
  return userJson ? JSON.parse(userJson) : null;
}

function saveCurrentUser(user) {
  sessionStorage.setItem('isLoggedIn', 'true');
  sessionStorage.setItem('userRole', user.role);
  sessionStorage.setItem('user', JSON.stringify(user));
}

function logoutUser() {
  sessionStorage.clear();
  window.location.href = 'index.html';
}

async function apiRequest(path, options = {}) {
  const user = getCurrentUser();
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {})
  };

  // Simple role header for this university project. A real system should use tokens.
  if (user) {
    headers['x-user-role'] = user.role;
    headers['x-user-id'] = user.id;
  }

  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.message || 'Something went wrong. Please try again.');
  }
  return data;
}

function requireRole(allowedRoles) {
  const user = getCurrentUser();
  if (!user || !allowedRoles.includes(user.role)) {
    alert('You do not have permission to open this page.');
    window.location.href = 'login.html';
    return null;
  }
  return user;
}
